package com.roomofdoom.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

import com.badlogic.gdx.utils.TimeUtils;
//Classe feita para os inimigos que seguem
public class Dinossauro{
	private Texture dinossaur;
	private Rectangle hitbox;
	private boolean hitted;

	private Player Principal;
	private long lastrespawntime;
	private float x;
	private float y;
	private int indice;
	
	//Construtor dos inimigos stalker
	public Dinossauro(Player Principal, Float x, Float y, int indice) {
		//Indice para decidir o sprite pertencente ao inimigo
		if(indice == 1) {
			dinossaur = new Texture("Dinossaur_Sprite00.png");
		}
		
		if(indice == 2) {
			dinossaur = new Texture("Jare_Sprite00.png");
		}
		
		if(indice == 3) {
			dinossaur = new Texture("Creeper_Sprite00.png");
		}
		
		hitbox = new Rectangle();
		this.Principal = Principal;
		hitbox.x = x + 30;
		hitbox.y = y + 30;
		this.x = x;
		this.y = y;
		hitbox.width = 30;
		hitbox.height = 40;
		hitted = false;
		this.indice = indice;
	}
	
	//Funcao para movimentos e para identificar se o inimigo sofreu algum dano
	public void Movements() {
		
		if(hitted == true) {
			
			hitbox.x = x + 30;
			hitbox.y = y + 30;
			if(TimeUtils.nanoTime() - lastrespawntime > 1000000000) {
				hitted = false;
				lastrespawntime = TimeUtils.nanoTime();
			}
		}
		
		//Funcao de movimentos para a direita
		if(hitbox.x < Principal.getX()) {
			hitbox.x += 20 * Gdx.graphics.getDeltaTime();
			if(indice == 1) {
				dinossaur = new Texture("Dinossaur_Sprite01.png");
			}
			
			if(indice == 2) {
				dinossaur = new Texture("Jare_Sprite00.png");
			}
			
			if(indice == 3) {
				dinossaur = new Texture("Creeper_Sprite00.png");
			}
		}
		
		//Funcao de movimentos para a esquerda
		if(hitbox.x > Principal.getX()) {
			hitbox.x -= 20 * Gdx.graphics.getDeltaTime();
			
			if(indice == 1) {
				dinossaur = new Texture("Dinossaur_Sprite00.png");
			}
			
			if(indice == 2) {
				dinossaur = new Texture("Jare_Sprite01.png");
			}
			
			if(indice == 3) {
				dinossaur = new Texture("Creeper_Sprite01.png");
			}
			
		}
		
		//Funcao de movimentos para baixo
		if(hitbox.y > Principal.getY()) {
			hitbox.y -= 20 * Gdx.graphics.getDeltaTime();
		}
		
		//Funcao de movimentos para cima
		if(hitbox.y < Principal.getY()) {
			hitbox.y += 20 * Gdx.graphics.getDeltaTime();
		}
		
	}
	
	
	//Funcao para mudar status de dano sofrido pelo inimigo
	public void setHitted(boolean hitted) {
		this.hitted = hitted;
	}
	
	//Funcao para pegar a imagem do inimigo
	public Texture getImage() {
		return dinossaur;
	}
	
	//Funcoes para pegar a hitbox do inimigo
	public float getX() {
		return hitbox.x;
	}
	
	public float getY() {
		return hitbox.y;
	}
	
	public Rectangle getHitbox() {
		return hitbox;
	}
}