package com.roomofdoom.game;

import java.util.LinkedList;

import com.badlogic.gdx.utils.TimeUtils;

//Classe para controle dos tiros
public class ControleTiros{
	LinkedList<Shoot> tiros = new LinkedList<>();
	RoomOfDoom room;
	private long lastshootime;
	
	//Funcao para adicionar os tiros ao personagem baseado no seu x e y
	public void adicionaTiros(float x, float y, String verifica, RoomOfDoom room) {
		if(TimeUtils.nanoTime() - lastshootime > 500000000) {
			Shoot tiro = new Shoot(verifica, x, y);
			tiros.addFirst(tiro);
			this.room = room;
			this.room.getTela().draw(tiro.getImage(), x, y);
			lastshootime = TimeUtils.nanoTime();
		}
	}
	
	//Funcao para a remocao e adicao de tiros, alem de chamar a funcao de movimento dos tiros
	public void run() {
		for(int i = 0; i < tiros.size(); i++) {
			Shoot tiro = tiros.removeFirst();
			tiro.Move();
			tiros.addLast(tiro);
		}
	}
}