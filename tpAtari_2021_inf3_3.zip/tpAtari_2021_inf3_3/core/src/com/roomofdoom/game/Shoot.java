package com.roomofdoom.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

//Classe para criacao dos tiros
public class Shoot{
	
	private Texture shoot;
	private Rectangle Shoot_hitbox;
	private String direcao;
	private int velocidade_tiro_horizontal_vertical = 225;
	private int velocidade_tiro_diagonal = 150;
	
	//Construtor para a classe tiros
	public Shoot(String verifica, Float x, Float y) {
		direcao = verifica;
		shoot = new Texture("tiro0.png");
		Shoot_hitbox = new Rectangle();
		Shoot_hitbox.x = x;
		Shoot_hitbox.y = y;
		Shoot_hitbox.height = 5;
		Shoot_hitbox.width = 5;
	}
	
	public void Move() {
		//Movimentos Verticais e horizontais
		if(direcao == "Up") {
			Shoot_hitbox.y += velocidade_tiro_horizontal_vertical * Gdx.graphics.getDeltaTime();
		
		}
		
		if(direcao == "Down") {
			Shoot_hitbox.y -= velocidade_tiro_horizontal_vertical * Gdx.graphics.getDeltaTime();
			
		}
		
		if(direcao == "Left") {
			Shoot_hitbox.x -= velocidade_tiro_horizontal_vertical * Gdx.graphics.getDeltaTime();
			
		}
		
		if(direcao == "Right") {
			Shoot_hitbox.x += velocidade_tiro_horizontal_vertical * Gdx.graphics.getDeltaTime();
			
		}
		
		//Movimentos diagonais
		
		if(direcao == "UpRight") {
			Shoot_hitbox.y += velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			Shoot_hitbox.x += velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			
		}
		
		if(direcao == "UpLeft") {
			Shoot_hitbox.y += velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			Shoot_hitbox.x -= velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			
		}
		
		if(direcao == "DownLeft") {
			Shoot_hitbox.x -= velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			Shoot_hitbox.y -= velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			
		}
		
		if(direcao == "DownRight") {
			Shoot_hitbox.y -= velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			Shoot_hitbox.x += velocidade_tiro_diagonal * Gdx.graphics.getDeltaTime();
			
		}
	}
	
	//Funcao para pegar a imagem do tiro
	public Texture getImage() {
		return shoot;
	}
	
	//Funcoes para pegar a hitbox dos tiros
	public Float getX() {
		return Shoot_hitbox.x;
	}
	
	public Float getY() {
		return Shoot_hitbox.y;
	}
	
	public Rectangle getHitbox() {
		return Shoot_hitbox;
	}
	public void setImage() {
		this.shoot = new Texture("tiro1.png");
	}
}
