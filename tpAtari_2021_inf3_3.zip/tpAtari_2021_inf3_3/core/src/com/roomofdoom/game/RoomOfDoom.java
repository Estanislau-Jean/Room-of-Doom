package com.roomofdoom.game;

import java.util.ArrayList;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.audio.Music;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

//Lista de bugs conhecidos: Dependendo do angulo de onde o tiro vem, os inimigos stalker pode nao receber o devido dano
//bug este que acontece por culpa da hitbox.
public class RoomOfDoom extends ApplicationAdapter{
	//Variaveis fundamentais para o funcionamento do jogo
	Player Principal;
	private int life = 6;
	private Dinossauro Stalker;
	private Dinossauro Stalker2;
	private Dinossauro Stalker3;
	ArrayList <GunEnemy> gunenemy = new ArrayList<GunEnemy>();
	ArrayList <String> direcoes = new ArrayList<String>();
	private SpriteBatch batch;
	private OrthographicCamera camera;
	private float coordenada_x[] = {-40, -40, 180, 180, 390, 390};
	private float coordenada_y[] = {0, 150, 210, -65, 0, 150};
	private boolean reupdate = false;
	private int enemy;
	//Musicas utilizadas nao sao de autoria nossa, elas pertencem ao Toby Fox, o criador de Undertale.
	//Musicas estas: Determination, Metal Crusher e Showtime
	//Os sons de laser foram adquiridos em: https://opengameart.org/content/laser-fire
	//Todos os sprites foram feitos pelo proprio grupo
	private Music roomMusic;
	private Music defeatMusic;
	private Music winMusic;
	private int Pontuacao = 0;
	private BitmapFont fonte;
	private String pontuacao;
	private String vida;
	private String sala;
	private int room = 1;
	private Room bordas;
	private boolean winner;
	private boolean restart = false;
	
	//A funcao create disponibilizada pela propria LibGDX, sua funcao e bem semelhante a de um construtor
	//ela serve basicamente para incializar as variaveis 
	@Override
	public void create () {
		//Inicializacao do personagem principal
		Principal = new Player(this, (float)50, (float)50);
		//Inicializacao das laterais da caixa
		bordas = new Room();
		//Inicializacao dos inimigos que seguem
		Stalker = new Dinossauro(Principal,(float) 222, (float)222, 1);
		Stalker2 = new Dinossauro(Principal, (float) 100, (float) 222, 2);
		Stalker3 = new Dinossauro(Principal, (float) 0, (float) 222, 3);
		//Inicializacao da camera
		camera = new OrthographicCamera();
		//Inicializacao dos inimigos atiradores
		for(int i = 0; i < 6; i++) {
			gunenemy.add(new GunEnemy(this, coordenada_x[i], coordenada_y[i], i));
		}
		gunenemy.get(0).setImage(0);
		gunenemy.get(1).setImage(0);
		gunenemy.get(2).setImage(3);
		gunenemy.get(3).setImage(2);
		gunenemy.get(4).setImage(1);
		gunenemy.get(5).setImage(1);
		direcoes.add("Right");
		direcoes.add("Right");
		direcoes.add("Down");
		direcoes.add("Up");
		direcoes.add("Left");
		direcoes.add("Left");
		enemy = 6;
		
	    camera.setToOrtho(false, 400, 550);
	    //Inicializacao da tela onde tudo acontece
		batch = new SpriteBatch();
		
		//Inicializacao da musica que e tocada no jogo
		roomMusic = Gdx.audio.newMusic(Gdx.files.internal("MetalCrusher.mp3"));
		roomMusic.setLooping(true);
		roomMusic.setVolume((float) 0.1);
	    roomMusic.play();
	    
	  //Inicializacao da musica que e tocada quando o jogador perde
	    defeatMusic = Gdx.audio.newMusic(Gdx.files.internal("Determination.mp3"));
	    defeatMusic.setLooping(true);
	    defeatMusic.setVolume((float) 0.1);
	    
	  //Inicializacao da musica que e tocada quando o jogador ganha
	    winMusic = Gdx.audio.newMusic(Gdx.files.internal("Showtime.mp3"));
		winMusic.setLooping(true);
		winMusic.setVolume((float) 0.1);
	    fonte = new BitmapFont();
	    fonte.setColor(Color.BLUE);
	}
	
	@Override
	public void render () {
		if(life > 0 || restart == true) {
			//Reupdate serve para criar novamente os inimigos atiradores, uma vez que foram removidos na 
			//hora de sua morte
			if(reupdate == true) {
				for(int i = 0; i < 6; i++) {
					gunenemy.add(new GunEnemy(this, coordenada_x[i], coordenada_y[i], i));
				}
				gunenemy.get(0).setImage(0);
				gunenemy.get(1).setImage(0);
				gunenemy.get(2).setImage(3);
				gunenemy.get(3).setImage(2);
				gunenemy.get(4).setImage(1);
				gunenemy.get(5).setImage(1);
				direcoes.add("Right");
				direcoes.add("Right");
				direcoes.add("Down");
				direcoes.add("Up");
				direcoes.add("Left");
				direcoes.add("Left");
				enemy = 6;
				
				reupdate = false;
				
				room++;
			}
			
			//Funcoes da propria LibGDX para limpar a tela e aplicar a cor preta
			Gdx.gl.glClearColor(0, 0, 0, 0);
		    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		    camera.update();
			batch.begin();
			pontuacao = "";
			sala = "";
			sala += "Room: " + String.valueOf(room);
			pontuacao += String.valueOf(Pontuacao);
			vida = "";
			vida += "Life: " + String.valueOf(life);
			//Setando o tamanho da fonte que sera escrita em tela
			fonte.getData().setScale(2 , 2);
			//Pontuacao obtida pelo jogador impressa em tela
			fonte.draw(batch, pontuacao, 50, 395 );
			//Quantidade de vida do jogador impressa em tela
			fonte.draw(batch, vida, 400, 395);
			//Room onde o jogador se encontra impressa em tela
			fonte.draw(batch, sala, 200, 395);
			//Desenho do personagem principal
			batch.draw(Principal.getImage(), Principal.getX(), Principal.getY());
			//Desenho do stalker
			batch.draw(Stalker.getImage(), Stalker.getX(), Stalker.getY());
			//Funcao para o movimento do personagem principal
			Principal.movements();
			//Funcao para o movimento do Stalker
			Stalker.Movements();
			//Quando a room for a 2 ou a 3 o Stalker 2 aparece para dificultar mais
			if(room == 2 || room == 3) {
				batch.draw(Stalker2.getImage(), Stalker2.getX(), Stalker2.getY());
				Stalker2.Movements();
			}
			//Quando a room for a 3 o Stalker 3 aparece para dificultar mais uma vez
			if(room == 3) {
				batch.draw(Stalker3.getImage(), Stalker3.getX(), Stalker3.getY());
				Stalker3.Movements();
			}
			
			for(int i = 0; i < gunenemy.size(); i++) {
				//Desenho do inimigo com base na sua posicao estatica, previamente inserida
				batch.draw(gunenemy.get(i).getImage(), gunenemy.get(i).getX(), gunenemy.get(i).getY());
				//Aqui e passado ao inimigo um vetor de Strings contendo posicoes nas quais ele deve atirar
				gunenemy.get(i).atirando(direcoes.get(i));
				//Dentro deste for os tiros disparados serao desenhados e a hitbox ira verificar
				//se ele atingiu o personagem principal ou se ela saiu para fora do mapa
				for(int j = 0; j < gunenemy.get(i).getControle().tiros.size(); j++) {
					Shoot b = gunenemy.get(i).getControle().tiros.get(j);
					batch.draw(b.getImage(), b.getX(), b.getY());
					if(b.getHitbox().overlaps(Principal.getHitbox())) {
						life -= 1;
						Principal.setX((float)30);
						Principal.setY((float)30);
						gunenemy.get(i).getControle().tiros.remove(j);
					}
					if(b.getX() > 500 || b.getX() < -40) {
						gunenemy.get(i).getControle().tiros.remove(j);
					}
					
					if(b.getY() > 395 || b.getY() < -60){
						gunenemy.get(i).getControle().tiros.remove(j);
					}
				}
			}
			
			//Aqui e feita uma serie comparacoes para saber qual das barreiras da sala vai mudar
			//Conforme o inimigo que vai atirar, ela deve ficar aberta por 3 segundos e fechar logo em seguida
			for(int i = 0; i < gunenemy.size();i++) {
				//Verificacao dos inimigos, foi necessario utilizar uma tag, visto que eles sao desalocados 
				//quando mortos 
				if(gunenemy.get(i).getTag() == 0) {
					
					if(gunenemy.get(i).getAtirando()) {
						bordas.setImageEsquerda(0);
						bordas.setEsquerdaY((float)-27);
					}
					
					if(gunenemy.get(i).getAtirando() == false) {
						bordas.setImageEsquerda(1);
						bordas.setEsquerdaY((float)-27);
					}
					
				}
				
				if(gunenemy.get(i).getTag() == 1) {
					
					if(gunenemy.get(i).getAtirando()) {
						bordas.setImageEsquerda2(0);
					}
					
					if(gunenemy.get(i).getAtirando() == false) {
						bordas.setImageEsquerda2(1);
					}
					
				}
				
				if(gunenemy.get(i).getTag() == 2) {
					
					if(gunenemy.get(i).getAtirando()) {
						bordas.setImageCima(1);
					}
					
					if(gunenemy.get(i).getAtirando() == false) {
						bordas.setImageCima(0);
					}
					
				}
				
				if(gunenemy.get(i).getTag() == 3) {
					
					if(gunenemy.get(i).getAtirando()) {
						bordas.setImageBaixo(1);
					}
					
					if(gunenemy.get(i).getAtirando() == false) {
						bordas.setImageBaixo(0);
					}
				}
				
				if(gunenemy.get(i).getTag() == 4) {
					
					if(gunenemy.get(i).getAtirando()) {
						bordas.setImageDireita(0);
						bordas.setDireitaY((float)-27);
					}
					
					if(gunenemy.get(i).getAtirando() == false) {
						bordas.setImageDireita(1);
						bordas.setDireitaY((float)-27);
					}
					
				}
				
				if(gunenemy.get(i).getTag() == 5) {
					
					if(gunenemy.get(i).getAtirando()) {
						bordas.setImageDireita2(0);
					}
					
					if(gunenemy.get(i).getAtirando() == false) {
						bordas.setImageDireita2(1);
					}
				}
			}
			
			//Lugar onde as bordas do mapa sao desenhadas, foram utilizadas duas bordas para a direita
			//e duas bordas para a esquerda, a fim de tornar a abertura das mesmas mais independente
			batch.draw(bordas.getImageDireita(), bordas.getDireitaX(), bordas.getDireitaY());
			batch.draw(bordas.getImageDireita2(), bordas.getDireita2X(), bordas.getDireita2Y());
			batch.draw(bordas.getImageEsquerda(), bordas.getEsquerdaX(), bordas.getEsquerdaY());
			batch.draw(bordas.getImageEsquerda2(), bordas.getEsquerda2X(), bordas.getEsquerda2Y());
			batch.draw(bordas.getImageBaixo(), bordas.getBaixoX(), bordas.getBaixoY());
			batch.draw(bordas.getImageCima(), bordas.getCimaX(), bordas.getCimaY());
			
			//Dentro deste for os tiros do personagem principal serao desenhados e verificados
			for(int i = 0; i < Principal.getControle().tiros.size(); i++) {
				Shoot a = Principal.getControle().tiros.get(i);
				a.setImage();
				batch.draw(a.getImage(), a.getX(), a.getY());
				//Se o inimigo que segue for atingido pelo tiro, seu estado de acertado e acionado
				//e ele volta a sua posicao inicial
				if(a.getHitbox().overlaps(Stalker.getHitbox())) {
					Stalker.setHitted(true);
					Principal.getControle().tiros.remove(i);
				}
				
				//Teste para verificar se os tiros estao saindo do mapa
				if(a.getX() < 20 && ( a.getY() < 200 && a.getY() > 80))  {
					Principal.getControle().tiros.remove(i);
				}
				
				//Teste para verificar se os tiros estao saindo do mapa
				if(a.getX() > 420 && ( a.getY() < 200 && a.getY() > 80)){
					Principal.getControle().tiros.remove(i);
				}
				
				//Teste para verificar se os tiros estao saindo do mapa
				if(a.getY() < 0 || a.getY() > 300) {
					Principal.getControle().tiros.remove(i);
				}
				
				//Assim como explicado anteriomente, este teste verifica se o Stalker foi acertado
				//Porem este stalker aparece apenas na room 2 e 3
				if(room == 2 || room == 3) {
					if(a.getHitbox().overlaps(Stalker2.getHitbox())) {
						Stalker2.setHitted(true);
						Principal.getControle().tiros.remove(i);
					}
				}
				
				//Teste para encontrar algum tiro que acerte o stalker que aparece na ultima room
				if(room == 3) {
					if(a.getHitbox().overlaps(Stalker3.getHitbox())) {
						Stalker3.setHitted(true);
						Principal.getControle().tiros.remove(i);
					}
				}
				
				//Teste para encontrar algum tiro que acerte os inimigos que atiram,
				//esse teste funciona com uma condicao de que eles somente serao acertados se
				//eles tiverem atirado a pelo menos 3 segundos atras(tempo de fechamento da barreira)
				//quando o inimigo e acertado ele deve ser removido do arraylist de inimigos
				//assim como o tiro que o acertou
				for(int j = 0; j < gunenemy.size(); j++) {
					if(a.getHitbox().overlaps(gunenemy.get(j).getGunEnemy()) && gunenemy.get(j).getAtirando()) {
						gunenemy.remove(j);
						direcoes.remove(j);
						Pontuacao += 175;
						enemy--;
						Principal.getControle().tiros.remove(i);
					}
					
				}
			}
			
			//Se o inimigo que segue encostar no nosso personagem, ele perde vida e retorna a sua posicao inicial
			if(Principal.getHitbox().overlaps(Stalker.getHitbox())) {
				life -= 1;
				Principal.setX((float)30);
				Principal.setY((float)30);
				Stalker.setHitted(true);
			}
			//Se o inimigo que segue encostar no nosso personagem, ele perde vida e retorna a sua posicao inicial
			if(Principal.getHitbox().overlaps(Stalker2.getHitbox())) {
				life -= 1;
				Principal.setX((float)30);
				Principal.setY((float)30);
				Stalker2.setHitted(true);
			}
			//Se o inimigo que segue encostar no nosso personagem, ele perde vida e retorna a sua posicao inicial
			if(Principal.getHitbox().overlaps(Stalker3.getHitbox())) {
				life -= 1;
				Principal.setX((float)30);
				Principal.setY((float)30);
				Stalker3.setHitted(true);
			}
			//Quando uma room e completamente finalizada, ela e aumentada e o reupdate e ativo
			if(enemy == 0 && room < 3) {
				reupdate = true;
			}
			
			//Quando a room 3 e finalizada o jogador ganha e entao a condicao de winner e ativada
			if(enemy == 0 && room == 3) {
				reupdate = false;
				winner = true;
			}
			
			batch.end();
			
			//Condicao para quando o jogador perde toda a vida, a tela e apagada e uma tela de fim de jogo entra
	} else if(life == 0){
				roomMusic.stop();
				defeatMusic.play();
				Gdx.gl.glClearColor(0, 0, 0, 0);
			    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
				batch.begin();
				batch.draw(new Texture("voceperdeu.png"), 50, 0);
				batch.end();
			}
		//Quando o jogador vence a room 3 a tela do vencedor aparece e entao o jogo acaba
	 if(winner) {
			roomMusic.stop();
			winMusic.play();
			Gdx.gl.glClearColor(0, 0, 0, 0);
		    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			batch.begin();
			batch.draw(new Texture("vocevenceu.png"), 100, 30);
			batch.end();
		}
		
	}
	
	//Funcao dispose fornecida pela propria biblioteca, para liberar a memoria depois de usada ajudando
	//no funcionamento do codigo
	@Override
	public void dispose () {
		Principal.getImage().dispose();
		for(int i = 0; i < gunenemy.size(); i++)
			gunenemy.get(i).getImage().dispose();
		Stalker.getImage().dispose();
		bordas.getImageBaixo().dispose();
		bordas.getImageDireita().dispose();
		bordas.getImageEsquerda().dispose();
		bordas.getImageCima().dispose();
		roomMusic.dispose();
		winMusic.dispose();
		defeatMusic.dispose();
		batch.dispose();
		
	}
	
	//funcao para pegar a classe RoomOfDoom
	public RoomOfDoom getRoom() {
		return this;
	}
	
	//funcao para pegar a tela onde tudo esta sendo printado
	public SpriteBatch getTela() {
		return batch;
	}
	
}
