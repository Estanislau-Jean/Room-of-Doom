package com.roomofdoom.game;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.TimeUtils;

//Classe feita para os inimigos atiradores presentes no jogo
public class GunEnemy implements Hero_Enemy{
	private Texture[] Enemy = new Texture[7];
	private Sound EnemySound;
	private Rectangle hitbox;
	private ControleTiros control = new ControleTiros();
	private RoomOfDoom room;
	private Texture aux;
	private Random gerador = new Random();
	private boolean atirando;
	private long lastShoot;
	private int tag;
	
	//Construtor do inimigo que atira
	public GunEnemy(RoomOfDoom room, Float x, Float y, int tag) {
		setImageSound();
		hitbox = new Rectangle();
		hitbox.x = x + 30;
		hitbox.y = y + 30;
		hitbox.width = 40;
		hitbox.height = 40;
		this.room = room;
		this.tag = tag;
	}
	
	//Funcao para inserir tanto a imagem quanto o som dos tiros ao inimigo
	@Override
	public void setImageSound() {
		Enemy[0] = new Texture("Enemy_Sprite00.png");
		Enemy[1] = new Texture("Enemy_Sprite01.png");
		Enemy[2] = new Texture("Enemy_Sprite02.png");
		Enemy[3] = new Texture("Enemy_Sprite03.png");
		Enemy[4] = new Texture("Enemy_Sprite04.png");
		Enemy[5] = new Texture("Enemy_Sprite05.png");
		
		EnemySound = Gdx.audio.newSound(Gdx.files.internal("laser5.wav"));
		
		aux = Enemy[0];
		
	}
	
	//Funcao para pegar a imagem utilizada como textura pelo inimigo
	@Override
	public Texture getImage() {
		// TODO Auto-generated method stub
		return aux;
	}
	
	//Funcoes para pegar a hitbox do inimigo
	@Override
	public float getX() {
		// TODO Auto-generated method stub
		return hitbox.x;
	}

	@Override
	public float getY() {
		// TODO Auto-generated method stub
		return hitbox.y;
	}
	
	public Rectangle getGunEnemy() {
		return hitbox;
	}
	
	//Funcao para mudar a hitbox no ponto x do inimigo
	public void setX(float x) {
		hitbox.x = x;
	}
	
	
	//Para setar a imagem utilizada pelo inimigo foi feito uma funcao que recebe o indice 
	public void setImage(int indice) {
			if(indice == 0) {
				aux = Enemy[0];
			}
			
			if(indice == 1) {
				aux = Enemy[1];
			}
			
			if(indice == 2) {
				aux = Enemy[2];
			}
			
			if(indice == 3) {
				aux = Enemy[3];
			}
			
			if(indice == 4) {
				aux = Enemy[4];
			}
			
			if(indice == 5) {
				aux = Enemy[5];
			}
	}
	
	public void setY(float y) {
		hitbox.y = y;
	}
	
	//Funcao feita para o inimigo atirar quando ele conseguir um valor igual a 0 dentro de um random
	public void atirando(String direcao) {
		if(gerador.nextInt(500) == 0) {
			atirando = true;
			lastShoot = TimeUtils.millis();
			//Toda vez que o inimigo atirar um som e disparado
			EnemySound.play((float) 0.1);
			//Verifica para qual direcao o inimigo deve atirar e entao passa para a funcao adicionaTiros
			if(direcao == "Left") {
	  		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, direcao, room.getRoom());
			}
	  	  
	  	  else if(direcao == "Right") {
	  		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, direcao, room.getRoom());
	  	  	} 
	  	  
	  	  else if(direcao == "Up") {
	  		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, direcao, room.getRoom());
	  	  	}
	  	  else if(direcao == "Down") {
	  		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, direcao, room.getRoom());
	  	  	}
		}
		control.run();
		//O inimigo deve ficar no minimo 3 segundos sem fechar a barreira para isso esse timeutils.millis
		if(TimeUtils.millis() - lastShoot > 3000) {
			 atirando = false;
  	  }
	}
	
	//Funcao para passar o controle de tiros
	public ControleTiros getControle() {
		return control;
	}
	
	//Funcao para passar o status de tiros do inimigo
	public boolean getAtirando() {
		return atirando;
	}
	
	//Funcao para passar a tag do inimigo
	public int getTag() {
		return tag;
	}
	
}