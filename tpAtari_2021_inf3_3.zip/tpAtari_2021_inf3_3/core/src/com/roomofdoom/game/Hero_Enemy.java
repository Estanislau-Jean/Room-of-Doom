package com.roomofdoom.game;

import com.badlogic.gdx.graphics.Texture;

interface Hero_Enemy{
	public void setImageSound();
	public Texture getImage();
	public float getX();
	public float getY();
}