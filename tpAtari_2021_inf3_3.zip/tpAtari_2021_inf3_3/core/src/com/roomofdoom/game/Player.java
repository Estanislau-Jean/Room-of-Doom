package com.roomofdoom.game;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.TimeUtils;

//Classe para o personagem principal
public class Player implements Hero_Enemy{
	
	private Texture hero;
	private Sound ShootSound;
	private Rectangle hitbox;
	private String verifica;
	private ControleTiros control = new ControleTiros();
	private RoomOfDoom room;
	private long lastShootSound;
	
	//Construtor do player
	public Player(RoomOfDoom room, Float x, Float y) {
		setImageSound();
		hitbox = new Rectangle();
		hitbox.x = 30 + x;
		hitbox.y =  30 + y;
		hitbox.width = 30;
		hitbox.height = 40;
		this.room = room;
	}
	
	//Funcao para inserir a imagem e o som do tiro do player
	public void setImageSound(){
		hero = new Texture("Hero_Sprite00.png");
		ShootSound = Gdx.audio.newSound(Gdx.files.internal("laser1.wav"));
	}
	
	//Funcao basica para devolver a textura do personagem principal
	public Texture getImage(){
		return hero;
	}
	
	//Funcao para mudar o ponto x e y do player
	public void setX(Float x) {
		hitbox.x = x + 30;
	}
	
	public void setY(Float y) {
		hitbox.y = y + 30;
	}
	
	//Funcao que contem tanto os movimentos do player principal
	//Quanto os tiros do mesmo
	public void movements() {
		
		if(Gdx.input.isTouched()) {
	         Vector2 touchPos = new Vector2();
	         touchPos.set(Gdx.input.getX(), Gdx.input.getY());
	      }
		  //Movimento para a esquerda 
	      if(Gdx.input.isKeyPressed(Keys.LEFT)) {
	    	  hitbox.x -= 70 * Gdx.graphics.getDeltaTime();
	    	  hero = new Texture("Hero_Sprite01.png");
	    	  verifica = "Left";
	      }
	    //Movimento para a direita 
	      if(Gdx.input.isKeyPressed(Keys.RIGHT)) {
	    	  hitbox.x += 70 * Gdx.graphics.getDeltaTime();
	    	  hero = new Texture("Hero_Sprite00.png");
	    	  verifica = "Right";
	      }
	    //Movimento para a cima 
	      if(Gdx.input.isKeyPressed(Keys.UP)) {
	    	  hitbox.y += 70 * Gdx.graphics.getDeltaTime();
	    	  hero = new Texture("Hero_Sprite02.png");
	    	  verifica = "Up";
	      }
	    //Movimento para a baixo 
	      if(Gdx.input.isKeyPressed(Keys.DOWN)) {
	    	  hitbox.y -= 70 * Gdx.graphics.getDeltaTime();
	    	  hero = new Texture("Hero_Sprite04.png");
	    	  verifica = "Down";
	      }
	    //Movimento para a diagonal baixo esquerda 
	      if(Gdx.input.isKeyPressed(Keys.DOWN) && Gdx.input.isKeyPressed(Keys.LEFT)) {
	    	  hero = new Texture("Hero_Sprite09.png");
	    	  verifica = "DownLeft";
	      }
	    //Movimento para a diagonal cima direita 
	      if(Gdx.input.isKeyPressed(Keys.UP) && Gdx.input.isKeyPressed(Keys.RIGHT)) {
	    	  hero = new Texture("Hero_Sprite06.png");
	    	  verifica = "UpRight";
	      }
	    //Movimento para a diagonal cima esquerda 
	      if(Gdx.input.isKeyPressed(Keys.UP) && Gdx.input.isKeyPressed(Keys.LEFT)) {
	    	  hero = new Texture("Hero_Sprite07.png");
	    	  verifica = "UpLeft";
	      }
	    //Movimento para a diagonal baixo direita 
	      if(Gdx.input.isKeyPressed(Keys.DOWN) && Gdx.input.isKeyPressed(Keys.RIGHT)) {
	    	  hero = new Texture("Hero_Sprite08.png");
	    	  verifica = "DownRight";
	      }

	      // Limites para o player n�o sair do mapa
	      if(hitbox.x < 20) hitbox.x = 20;
	      if(hitbox.x > 400 - 30) hitbox.x = 400 - 30;
	      if(hitbox.y < 0) hitbox.y = 0;
	      if(hitbox.y > 240 - 40) hitbox.y = 240 - 40;
	      
	      //Trecho para detectar se o usuario quer atirar e com isso arruma a saida do tiro do personagem 
	      if(Gdx.input.isKeyPressed(Keys.SPACE)) {
	    	  if(TimeUtils.nanoTime() - lastShootSound > 500000000) {
	    		  ShootSound.play((float) 0.1);
	    		  lastShootSound = TimeUtils.nanoTime();
	    	  }
	    	  if(verifica == "Left") {
	    		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, verifica, room.getRoom());
	    	  }
	    	  
	    	  else if(verifica == "Right") {
	    		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, verifica, room.getRoom());
	    	  } 
	    	  
	    	  else if(verifica == "DownRight") {
	    		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, verifica, room.getRoom());
	    	  }
	    	  
	    	  else if(verifica == "DownLeft") {
	    		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, verifica, room.getRoom());
	    	  }
	    	  
	    	  else if(verifica == "UpLeft") {
	    		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 35, verifica, room.getRoom());
	    	  }
	    	  
	    	  else if(verifica == "UpRight") {
	    		  control.adicionaTiros(hitbox.x + 30, hitbox.y + 30, verifica, room.getRoom());
	    	  }
	    	  
	    	  else {
	    		  control.adicionaTiros(hitbox.x + 40, hitbox.y + 35, verifica, room.getRoom());
	    	  }
	    		  
	      }
	      control.run();
	}
	
	//Funcao para pegar a hitbox do personagem principal
	public float getX() {
		return hitbox.x;
	}
	
	public float getY() {
		return hitbox.y;
	}
	
	//Funcao para pegar a direcao na qual o player quer atirar
	public String getVerifica() {
		return verifica;
	}
	
	//Funcao para pegar o controle de tiros do player principal
	public ControleTiros getControle() {
		return control;
	}
	
	public Rectangle getHitbox() {
		return hitbox;
	}
	
}

