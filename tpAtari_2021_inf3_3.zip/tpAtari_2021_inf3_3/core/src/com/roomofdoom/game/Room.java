package com.roomofdoom.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

//Classe utilizada para a formacao da estrutura da caixa
public class Room{
	private Texture lateralesq;
	private Texture lateralesq2;
	private Texture lateraldir;
	private Texture lateraldir2;
	private Texture ladocima;
	private Texture ladobaixo;
	private Texture[] VetImagens = new Texture[6];
	private Rectangle esquerda;
	private Rectangle direita;
	private Rectangle esquerda2;
	private Rectangle direita2;
	private Rectangle cima;
	private Rectangle baixo;
	
	//Construtor da sala
	public Room() {
		//Vetor de imagens dos lados da caixa
		VetImagens[0] = new Texture("sprite_0.png");
		VetImagens[1] = new Texture("sprite_1.png");
		VetImagens[2] = new Texture("sprite_2.png");
		VetImagens[3] = new Texture("sprite_3.png");
		VetImagens[4] = new Texture("sprite_4.png");
		VetImagens[5] = new Texture("sprite_5.png");
		
		//Hitbox da caixa
		esquerda = new Rectangle();
		direita = new Rectangle();
		cima = new Rectangle();
		baixo = new Rectangle();
		direita2 = new Rectangle();
		esquerda2 = new Rectangle();
		
		
		esquerda.x = -30;
		esquerda.y = -150;
		esquerda.width = 40;
		esquerda.height = 265;
		lateralesq = VetImagens[3];
		lateralesq2 = VetImagens[3];
		
		esquerda2.x = -30;
		esquerda2.y = -38;
		esquerda2.width = 40;
		esquerda2.height = 265;
		
		direita.x = 355;
		direita.y = -150;
		direita.width = 40;
		direita.height = 265;
		lateraldir = VetImagens[3];
		lateraldir2 = VetImagens[3];
		
		direita2.x = 355;
		direita2.y = -38;
		direita2.width = 40;
		direita2.height = 265;
		
		cima.x = 55;
		cima.y = 10;
		cima.width = 20;
		cima.height = 100;
		ladocima = VetImagens[1];
		
		baixo.x = 55;
		baixo.y = -215;
		baixo.width = 20;
		baixo.height = 40;
		ladobaixo = VetImagens[1];
	}
	
	//Serie de funcoes get e set necessarias para a manutencao dos valores da caixa
	
	public Rectangle getCimaHitbox() {
		return cima;
	}
	
	public Rectangle getBaixoHitbox() {
		return baixo;
	}
	
	public Rectangle getDireitaHitbox() {
		return direita;
	}
	
	public Rectangle getEsquerdaHitbox() {
		return esquerda;
	}
	
	public Float getCimaX() {
		return cima.x;
	}
	
	public Float getCimaY() {
		return cima.y;
	}
	
	public Float getBaixoX() {
		return baixo.x;
	}
	
	public Float getBaixoY() {
		return baixo.y;
	}
	
	public Float getEsquerdaX() {
		return esquerda.x;
	}
	
	public Float getEsquerdaY() {
		return esquerda.y;
	}
	
	public Float getDireitaX() {
		return direita.x;
	}
	
	public Float getDireitaY() {
		return direita.y;
	}
	
	public Float getEsquerda2X() {
		return esquerda2.x;
	}
	
	public Float getEsquerda2Y() {
		return esquerda2.y;
	}
	
	public Float getDireita2X() {
		return direita2.x;
	}
	
	public Float getDireita2Y() {
		return direita2.y;
	}
	
	public void setDireitaY(Float y) {
		direita.y = y;
	}
	
	public void setEsquerdaY(Float y) {
		esquerda.y =  y;
	}
	
	public Texture getImageCima() {
		return ladocima;
	}
	
	public Texture getImageBaixo() {
		return ladobaixo;
	}
	
	public Texture getImageEsquerda() {
		return lateralesq;
	}
	
	public Texture getImageDireita() {
		return lateraldir;
	}
	
	public Texture getImageEsquerda2() {
		return lateralesq2;
	}
	
	public Texture getImageDireita2() {
		return lateraldir2;
	}
	
	public void setImageEsquerda(int indice) {
		if(indice == 0) {
			lateralesq = VetImagens[4];
		}
		
		if(indice == 1) {
			lateralesq = VetImagens[5];
		}
	}
		
		public void setImageEsquerda2(int indice) {
			if(indice == 0) {
				lateralesq2 = VetImagens[2];
			}
			
			if(indice == 1) {
				lateralesq2 = VetImagens[3];
			}
		}
	
	public void setImageDireita(int indice) {
		if(indice == 0) {
			lateraldir = VetImagens[4];
		}
		
		if(indice == 1) {
			lateraldir = VetImagens[5];
		}

	}
	
	public void setImageDireita2(int indice) {
		if(indice == 0) {
			lateraldir2 = VetImagens[2];
		}
		
		if(indice == 1) {
			lateraldir2 = VetImagens[3];
		}

	}
	
	public void setImageCima(int indice) {
		if(indice == 0) {
			ladocima = VetImagens[1];
		}
		
		if(indice == 1) {
			ladocima = VetImagens[0];
		}
	}
	
	public void setImageBaixo(int indice) {
		if(indice == 0) {
			ladobaixo = VetImagens[1];
		}
		
		if(indice == 1) {
			ladobaixo = VetImagens[0];
		}
	}
	
}