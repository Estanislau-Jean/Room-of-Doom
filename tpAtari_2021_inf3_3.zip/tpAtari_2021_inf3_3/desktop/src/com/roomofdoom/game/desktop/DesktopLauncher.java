package com.roomofdoom.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.roomofdoom.game.RoomOfDoom;

public class DesktopLauncher {
	public static void main (String[] arg) {
		//Main onde a tela e criada e todo o algoritmo e iniciado
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.title = "RoomOfDoom";
		config.height = 400;
		config.width = 550;		
		new LwjglApplication(new RoomOfDoom(), config);
		
	}
}
